from oyster_catchers.server import server

server.launch()
