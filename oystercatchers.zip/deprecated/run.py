#!/usr/bin/env python

from server import server
server.port = 8521 # The default
server.launch()
